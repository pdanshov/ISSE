/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic startup code for a JUCE application.

  ==============================================================================
*/

%%app_headers%%

//==============================================================================
int main (int argc, char* argv[])
{

    // ..your code goes here!


    return 0;
}
