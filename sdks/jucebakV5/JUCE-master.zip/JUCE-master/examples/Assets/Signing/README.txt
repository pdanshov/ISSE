This signing key is used to sign the android version of the in-app purchase sample app so that authenticated requests to the play store API can be tested.

This key has only been used to sign the in-app purchase sample app and therefore cannot be used for any other apps. It’s impossible to use to sign any existing apps on the app store.

! Do not use this key for your own production apps !
